from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import requests
import os
import uuid

# ایجاد اپلیکیشن Flask
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# تنظیمات API و چت
TOKEN = 'bot333725:b380f262-c3d2-4433-a16b-28dbc83c10ad'
CHAT_ID = '@post_sender'
API_URL = "https://eitaayar.ir/api"

# تابع ارسال پیام به API
def send_message_to_eita(chat_id, message_text):
    try:
        url = f"{API_URL}/{TOKEN}/sendMessage"
        payload = {"chat_id": chat_id, "text": message_text}
        response = requests.post(url, data=payload)
        if response.status_code != 200:
            print(f"Failed to send message: {response.text}")
        else:
            print("Message sent successfully.")
        return response.json()
    except Exception as e:
        print(f"Error sending message: {e}")

# تابع بارگذاری فایل JSON
def load_json_file(filepath, default_value):
    if not os.path.exists(filepath):
        with open(filepath, 'w') as file:
            json.dump(default_value, file)
    with open(filepath, 'r') as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return default_value

# صفحه اصلی
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form.get('name')
        if not name:
            flash("لطفاً نام خود را وارد کنید.", "danger")
            return redirect(url_for('index'))
        session['name'] = name
        session['user_id'] = str(uuid.uuid4())
        session['ip'] = request.remote_addr
        return redirect(url_for('select_survey'))
    return render_template('index.html')

# انتخاب نظرسنجی
@app.route('/select_survey')
def select_survey():
    ip = session.get('ip', '')
    completed_surveys = load_json_file('data/completed_surveys.json', {})

    # بررسی اینکه آیا کاربر قبلاً همه نظرسنجی‌ها را تکمیل کرده است
    if ip in completed_surveys.get("exam", []) and ip in completed_surveys.get("haram", []):
        flash("شما قبلاً در همه نظرسنجی‌ها شرکت کرده‌اید.", "info")
        return redirect(url_for('index'))

    available_surveys = []
    if ip not in completed_surveys.get("exam", []):
        available_surveys.append("exam")
    if ip not in completed_surveys.get("haram", []):
        available_surveys.append("haram")

    return render_template('select_survey.html', available_surveys=available_surveys)

# نظرسنجی امتحانات
@app.route('/exam_survey', methods=['GET', 'POST'])
def exam_survey():
    ip = session.get('ip', '')
    completed_surveys = load_json_file('data/completed_surveys.json', {})

    # بررسی اینکه آیا کاربر قبلاً این نظرسنجی را تکمیل کرده است
    if ip in completed_surveys.get("exam", []):
        flash("شما قبلاً به سوالات امتحانی پاسخ داده‌اید.", "warning")
        return redirect(url_for('select_survey'))

    if request.method == 'POST':
        name = session.get('name', 'نام وارد نشده')
        user_id = session.get('user_id', 'بدون شناسه')
        questions = {
            'q1': "فاصله بین امتحانات:",
            'q2': "امتحانات جنبی، قبل از شروع ترم برگزار شود؟",
            'q3': "پاسخ گویی ناظرین به سوالات در جلسه:",
            'q4': "سوالات امتحانی در چه سطحی بود؟ بهمراه عنوان درس:",
            'q5': "مطالعه مدرسه در زمان امتحانات الزامی باشد:",
            'q6': "میزان عملکرد شما در امتحان ترم:",
            'q7': "علت ضعیف عمل کردن شما در امتحان ترم:",
            'q8': "راهکار شما در ارتقای معدل:"
        }
        responses = {q: request.form.get(q) for q in questions}

        # ذخیره پاسخ‌ها
        all_responses = load_json_file('data/exam_responses.json', [])
        all_responses.append({"user_id": user_id, "name": name, "ip": ip, "responses": responses})
        with open('data/exam_responses.json', 'w') as file:
            json.dump(all_responses, file)

        # به‌روزرسانی نظرسنجی‌های کامل‌شده
        completed_surveys.setdefault("exam", []).append(ip)
        with open('data/completed_surveys.json', 'w') as file:
            json.dump(completed_surveys, file)

        # ارسال نتایج به API
        result_text = f"📊 **نتایج نظرسنجی امتحانات** 📊\n👤 {name} | 🌐 {ip} | 🆔 {user_id}\n"
        for q, question_text in questions.items():
            result_text += f"\n❓ {question_text}: {responses[q]}"
        result_text += f"\n\n👥 **تعداد شرکت‌کنندگان:** {len(all_responses)} نفر"
        send_message_to_eita(CHAT_ID, result_text)

        flash('نظر شما ثبت شد!', 'success')
        return redirect(url_for('select_survey'))

    return render_template('exam_survey.html')

# نظرسنجی حرم
@app.route('/haram_survey', methods=['GET', 'POST'])
def haram_survey():
    ip = session.get('ip', '')
    completed_surveys = load_json_file('data/completed_surveys.json', {})

    # بررسی اینکه آیا کاربر قبلاً این نظرسنجی را تکمیل کرده است
    if ip in completed_surveys.get("haram", []):
        flash("شما قبلاً به سوالات حرم پاسخ داده‌اید.", "warning")
        return redirect(url_for('select_survey'))

    if request.method == 'POST':
        name = session.get('name', 'نام وارد نشده')
        user_id = session.get('user_id', 'بدون شناسه')
        questions = {
            'hq1': "ارزیابی شما از کلیت برنامه حرم:",
            'hq2': "برنامه سخنرانی:",
            'hq3': "برنامه مناجات خوانی:",
            'hq4': "برنامه حلقه معرفت:",
            'hq5': "برنامه حرم شناسی:",
            'hq6': "پذیرایی:",
            'hq7': "درصورت توفیق مجدد، چند درصد علاقه به شرکت دارید؟",
            'hq8': "نظر شما در مورد بهتر اجرا شدن این برنامه:"
        }
        responses = {q: request.form.get(q) for q in questions}

        # ذخیره پاسخ‌ها
        all_responses = load_json_file('data/haram_responses.json', [])
        all_responses.append({"user_id": user_id, "name": name, "ip": ip, "responses": responses})
        with open('data/haram_responses.json', 'w') as file:
            json.dump(all_responses, file)

        # به‌روزرسانی نظرسنجی‌های کامل‌شده
        completed_surveys.setdefault("haram", []).append(ip)
        with open('data/completed_surveys.json', 'w') as file:
            json.dump(completed_surveys, file)

        # ارسال نتایج به API
        result_text = f"📊 **نتایج نظرسنجی حرم** 📊\n👤 {name} | 🌐 {ip} | 🆔 {user_id}\n"
        for q, question_text in questions.items():
            result_text += f"\n❓ {question_text}: {responses[q]}"
        result_text += f"\n\n👥 **تعداد شرکت‌کنندگان:** {len(all_responses)} نفر"
        send_message_to_eita(CHAT_ID, result_text)

        flash('نظر شما ثبت شد!', 'success')
        return redirect(url_for('select_survey'))

    return render_template('haram_survey.html')

# درخواست دسترسی مجدد
@app.route('/request_access', methods=['GET', 'POST'])
def request_access():
    if request.method == 'POST':
        name = request.form.get('name', 'نامشخص')
        reason = request.form.get('reason', 'بدون توضیحات')
        ip = session.get('ip', '')
        message = f"کاربر {name} با IP: {ip} درخواست دسترسی دوباره کرده است.\nدلیل: {reason}"
        send_message_to_eita(CHAT_ID, message)
        flash("درخواست شما ارسال شد و به زودی بررسی خواهد شد.", "info")
        return redirect(url_for('index'))
    return render_template('request_access.html')

if __name__ == '__main__':
    app.run(debug=True)